const express = require("express");
const router = express.Router();

//import controllers methods in routes
const {
  create,
  allPosts,
  readPost,
  updatePost,
  deletePost,
} = require("../controllers/post");

const { requireSignin } = require("../controllers/auth");

router.post("/post", requireSignin, create);
router.get("/posts", allPosts);
router.get("/post/:slug", readPost);
router.put("/post/:slug", requireSignin, updatePost);
router.delete("/post/:slug", deletePost);

module.exports = router;
