const jwt = require("jsonwebtoken");

const expressJwt = require("express-jwt");

exports.login = (req, res) => {
  const { name, password } = req.body;
  //console.log(process.env.PASSWORD, "This is password");

  if (password === process.env.PASSWORD) {
    //generate token and send to client/react
    const token = jwt.sign({ name }, process.env.JWT_SECRET_KEY, {
      expiresIn: "1d",
    });

    return res.json({ token, name });
  } else {
    return res.status(400).json({
      error: "Incorrect password Sir",
    });
  }
};

exports.requireSignin = expressJwt({
  secret: process.env.JWT_SECRET_KEY,
  algorithms: ["HS256"],
});
