const mongoose = require("mongoose");
const { objectId } = mongoose.Schema;

const postSchema = new mongoose.Schema(
  {
    title: {
      type: String,
      trim: true,
      min: 3,
      max: 150,
      required: true,
    },

    slug: {
      type: String,
      unique: true, //if title exits then throw an erro two posts with same name is not possible
      index: true, // help in efficent execution of quries in MongoDB
      lowercase: true,
    },
    content: {
      type: {}, // anything so we set type empty object
      required: true,
      min: 20,
      max: 2000000,
    },

    user: {
      type: String,
      default: "Admin",
    },
  },
  { timestamps: true }
);

module.exports = mongoose.model("Post", postSchema);
